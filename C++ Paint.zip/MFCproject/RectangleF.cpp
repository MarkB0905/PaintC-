#include "stdafx.h" // must be 1st
#include "RectangleF.h"

IMPLEMENT_SERIAL(RectangleF, CObject, 1)

RectangleF::RectangleF(CPoint p1, CPoint p2) 
	:Figure(p1,p2)
{
}

void RectangleF::Draw(CDC* dc) const
{
	
	CPen pen1, * oldPen;
	pen1.CreatePen(PS_SOLID, pensize/* width */, pen);
	oldPen = dc->SelectObject(&pen1);
	CBrush myBrush, * oldBrush;
	myBrush.CreateSolidBrush(filling);
	oldBrush = dc->SelectObject(&myBrush);
	dc->Rectangle(P1.x, P1.y, P2.x, P2.y);
	dc->SelectObject(oldBrush);
	dc->SelectObject(oldPen);
	DeleteObject(pen1);
	DeleteObject(myBrush);
}