#pragma once

#include "RectangleF.h"
class DavidStar :public RectangleF {
	DECLARE_SERIAL(DavidStar)   
public:
	DavidStar() {}
	DavidStar(CPoint p1, CPoint p2);
	void Draw(CDC* dc) const;
};
