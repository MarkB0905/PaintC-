#include "stdafx.h"  
#include "Figure.h"

IMPLEMENT_SERIAL(Figure, CObject, 1)

void Figure::Serialize(CArchive& ar)
{
	CObject::Serialize(ar);
	if (ar.IsStoring())
	{
		ar << P1;
		ar << P2;
		ar << pensize;
		ar << pen;
		ar << filling;
	}
	else // Loading, not storing
	{
		ar >> P1;
		ar >> P2;
		ar >> pensize;
		ar >> pen;
		ar >> filling;
	}
}



