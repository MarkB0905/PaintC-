#pragma once
#include "stdafx.h"
class Figure: public CObject {

	DECLARE_SERIAL(Figure)   
	CPoint P1;
	CPoint P2;
public:
	Figure() {}

	COLORREF pen;
	COLORREF filling;
	int pensize;
	Figure(CPoint p1, CPoint p2):
		P1(p1), P2(p2)
	{
		pensize = 2;
		filling = RGB(255, 255, 255);
		pen = RGB(0, 0, 0);
	}
	void Serialize(CArchive& ar);

	virtual void Draw(CDC *dc) const
	{
		dc->Rectangle(P1.x, P1.y, P2.x, P2.y);
	}
	CPoint getP1() const 
	{ 
		return P1;
	}
	CPoint getP2() const
	{
		return P2;
	}
	virtual void Redefine(CPoint p1, CPoint p2) 
	{
		P1 = p1; P2 = p2;
	}
};
